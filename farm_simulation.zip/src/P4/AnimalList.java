package P4;

import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class AnimalList implements Iterable<Animal>, Serializable{
	
	private AnimalNode head;
	private AnimalNode tail;
	private int size;
	
	public AnimalList() {
		this.head = null;
		this.tail = null;
		this.size = 0;
	}
	public int size() {
		return size;
	}
	public boolean isEmpty() {
		return size == 0;
	}
	public void addFirst(Animal animal) {
		AnimalNode newAnimalNode = new AnimalNode(animal);
		if(head == null) {
			head = newAnimalNode;
			tail = newAnimalNode;
		}else {
			newAnimalNode.next = head.next;
			head = newAnimalNode;
		}
		size++;
	}
	public void addLast(Animal animal) {
		AnimalNode newAnimalNode = new AnimalNode(animal);
		if(tail == null) {
			head = newAnimalNode;
			tail = newAnimalNode;
		}else {
			tail.next = newAnimalNode;
			tail = newAnimalNode;
		}
		size++;
	}
	public void add(int index,Animal animal) {
		AnimalNode newAnimalNode = new AnimalNode(animal);
		if(index < 0 || index >= size) 
			throw new IndexOutOfBoundsException();
		else if(index == 0)
			addFirst(animal);
		else if(index == size)
			addLast(animal);
		else {
			AnimalNode current = getAnimalNodeAtIndex(index - 1);
			newAnimalNode.next = current.next;
			current.next = newAnimalNode;
		}
		size++;
	}
	public Animal removeFirst() {
		if(head == null) {
			return null;
		}else {
			AnimalNode temp = head;
			head = head.next;
			size--;
			if (head == null)
				tail = null;
			return temp.element;
		}
	}
	public Animal remove(int index) {
		if(index < 0 || index >= size) 
			throw new IndexOutOfBoundsException();
		else if(index == 0)
			return removeFirst();
		else if(index == size - 1)
			return removeLast();
		else {
			AnimalNode current = getAnimalNodeAtIndex(index - 1);
			AnimalNode temp = current.next;
			current.next = current.next.next;
			size--;
			return temp.element;
		}
		
	}
	
	public Animal removeLast() {
		if (head == null) {
			return null;
		}
		if (head == tail) { // If there's only one AnimalNode in the list
	        Animal removedElement = head.element;
	        head = null;
	        tail = null;
	        size--;
	        return removedElement;
	    }else {
			AnimalNode current = getAnimalNodeAtIndex(size-2);
			AnimalNode temp = current.next;
			current.next = null;
			tail = current;
			size --;
			return temp.element;	
		}
	}
	public Animal get(int index) {
		if(index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}else {
			AnimalNode current = getAnimalNodeAtIndex(index);
			return current.element;
		}
		
	}
	public Animal getFirst() {
		return (head == null) ? null : head.element;
	}
	public Animal getLast() {
		return (tail == null) ? null : tail.element;
	}	
	public AnimalNode getAnimalNodeAtIndex(int index) {
		if(index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		AnimalNode current = head;
		for(int i = 0; i < index; i++) 
			current = current.next;
		return current;
	}
	public Animal set(int index, Animal animal) {
		if(index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}else {
			AnimalNode current = getAnimalNodeAtIndex(index);
			Animal temp = current.element;
			current.element = animal;
			return temp;
		}
	}
	public String toString() {
		StringBuilder sb = new StringBuilder();
		AnimalNode current = head;
		
		while(current != null) {
			sb.append(current.element.toString()).append("\n");
			current = current.next;
		}
		
		return sb.toString();
	}
	public AnimalList getHungryAnimals() {
		AnimalList hungryAnimals = new AnimalList(); 
	    
	    for (Animal animal : this) {  
	        if (animal.getEnergy() < 50) {
	            hungryAnimals.addLast(animal);  
	        }
	    }
	    
	    return hungryAnimals.size > 0 ? hungryAnimals : null; 
	}
	public AnimalList getStarvingAnimals() {
		AnimalList StarvingAnimals = new AnimalList(); 
	    
	    for (Animal animal : this) {  
	        if (animal.getEnergy() < 17) {
	            StarvingAnimals.addLast(animal);  
	        }
	    }
	    
	    return StarvingAnimals.size > 0 ? StarvingAnimals : null; 
	}
	public AnimalList getAnimalsInBarn() {
	    AnimalList animalsInBarn = new AnimalList();  

	    for (Animal animal : this) {  
	        double x = animal.getX();
	        double y = animal.getY();

	        // 
	        if (x >= 450 && x <= 550 && y >= 50 && y <= 150) {
	            animalsInBarn.addLast(animal); 
	        }
	    }

	    return animalsInBarn.size > 0 ? animalsInBarn : null;  
	}
	public double getRequiredFood() {
	    double totalFoodRequired = 0.0;

	    for (Animal animal : this) {  
	        totalFoodRequired += (100 - animal.getEnergy()); 
	    }

	    return totalFoodRequired;
	}

	@Override
	public Iterator<Animal> iterator() {
		// TODO Auto-generated method stub
		return new MyIterator();
	}
	private class MyIterator implements Iterator<Animal>{
		private AnimalNode current;
		
		public MyIterator() {
			this.current = head;
		}

		@Override
		public boolean hasNext() {
			return current != null;
		}

		@Override
		public Animal next() {
			if(!hasNext()) {
				throw new NoSuchElementException();
			}
			Animal data = current.element;
			current = current.next;
			return data;
		}
		
	}
	
	private static class AnimalNode {
		Animal element;
		AnimalNode next;
		
		public AnimalNode(Animal a) {
			element = a;
			next = null;
		}
	}

}
